// بعد از "npx cap add android" یک بار اجرا کنید:  node setup-android.js
// مجوزهای ذخیره‌ی فایل را به AndroidManifest.xml اضافه می‌کند.
const fs = require('fs');
const f = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(f)) { console.error('فایل ' + f + ' پیدا نشد. اول دستور  npx cap add android  را اجرا کنید.'); process.exit(1); }
let x = fs.readFileSync(f, 'utf8');
if (!x.includes('requestLegacyExternalStorage')) x = x.replace('<application', '<application android:requestLegacyExternalStorage="true"');
for (const p of ['READ_EXTERNAL_STORAGE', 'WRITE_EXTERNAL_STORAGE']) {
  if (!x.includes('android.permission.' + p)) x = x.replace('<application', `<uses-permission android:name="android.permission.${p}" android:maxSdkVersion="32" />\n    <application`);
}
fs.writeFileSync(f, x);
console.log('OK: مجوزهای ذخیره‌ی فایل اضافه شد.');
